﻿namespace Interface
{
    public enum ChessmanType
    {
        Rook, // ладья
        Bishop, // слон
        Knight // конь
    }
}
